import processing.core.*; 

import ddf.minim.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class MakeyMakeyTheTech extends PApplet {

/**
 * Load Sample
 * by Damien Di Fede.
 *  
 * This sketch demonstrates how to use the <code>loadSample</code> 
 * method of <code>Minim</code>. The <code>loadSample</code> 
 * method allows you to specify the sample you want to load with 
 * a <code>String</code> and optionally specify what you 
 * want the buffer size of the returned <code>AudioSample</code> 
 * to be. If you don't specify a buffer size, the returned sample 
 * will have a buffer size of 1024. Minim is able to load wav files, 
 * au files, aif files, snd files, and mp3 files. When you call 
 * <code>loadSample</code>, if you just specify the filename it will 
 * try to load the sample from the data folder of your sketch. However, 
 * you can also specify an absolute path (such as "C:\foo\bar\thing.wav") 
 * and the file will be loaded from that location (keep in mind that 
 * won't work from an applet). You can also specify a URL (such as 
 * "http://www.mysite.com/mp3/song.mp3") but keep in mind that if you 
 * run the sketch as an applet you may run in to security restrictions 
 * if the applet is not on the same domain as the file you want to load. 
 * You can get around the restriction by signing the applet. Before you 
 * exit your sketch make sure you call the <code>close</code> method 
 * of any <code>AudioSamples</code>'s you have received from 
 * <code>loadSample</code>.
 *
 * An <code>AudioSample</code> is a special kind of file playback that 
 * allows you to repeatedly <i>trigger</i> an audio file. It does this 
 * by keeping the entire file in an internal buffer and then keeping a 
 * list of trigger points. <code>AudioSample</code> supports up to 20 
 * overlapping triggers, which should be plenty for short sounds. It is 
 * not advised that you use this class for long sounds (like entire songs, 
 * for example) because the entire file is kept in memory.
 * 
 * Press 'k' to trigger the sample.
 */
// 



Minim minim;
AudioSample kick;
AudioSample kick2;
AudioSample clap;
AudioSample phresh;
AudioSample airhorn;
AudioSample he;
AudioSample imma;
AudioSample bd808;
AudioSample clap808;
AudioSample hihat808;
AudioSample cowbell808;
AudioSample snare808;
AudioSample mnt1;
AudioSample mnt2;
AudioSample mnt3;
AudioSample mnt4;

int x = 0;

//import processing.video.*;
//
//Movie movie;

public void setup()
{
  noCursor();
  size(1920, 1080, P2D);
  //hit cmd + shift + r // to full screen

  //  size(screen.width, screen.height, P2d);
  // always start Minim before you do anything with it

  minim = new Minim(this);
  // load BD.mp3 from the data folder with a 1024 sample buffer
  // kick = Minim.loadSample("BD.mp3");
  // load BD.mp3 from the data folder, with a 512 sample buffer
  kick = minim.loadSample("BD.mp3", 320);
  kick2 = minim.loadSample("Lit_Bass.wav", 320);
  clap = minim.loadSample("Clap1.wav", 320);
  phresh = minim.loadSample("Phreshfx.wav", 320);
  airhorn = minim.loadSample("airhorn.wav", 320);
  he = minim.loadSample("He.wav", 320);
  imma = minim.loadSample("Imma.wav", 320);
  he.setVolume(3.0f);
  ///////////////////////////
  bd808 = minim.loadSample("808KickDrum10.mp3", 380);
  clap808 = minim.loadSample("808Clap.mp3", 380);
  hihat808 = minim.loadSample("808ClHihat1.mp3", 380);
  cowbell808 = minim.loadSample("808Cowbell.mp3", 380);
  snare808 = minim.loadSample("808SnareDrum6.mp3", 380);
  bd808.setVolume(2.0f);
  hihat808.setVolume(2.0f);
  cowbell808.setVolume(2.0f);
  snare808.setVolume(2.0f);
  ///////////////////////////
  mnt1 = minim.loadSample("Mountain_1.mp3", 320);
  mnt2 = minim.loadSample("Mountain_2.mp3", 320);
  mnt3 = minim.loadSample("Mountain_3.mp3", 320);
  mnt4 = minim.loadSample("Mountain_4.mp3", 320);

  //  movie = new Movie(this, "James_1_1.mov");
}

//void movieEvent(Movie movie) {
//  movie.read();
//}

public void draw()
{
  if (x == 0) {
    background(0);
  }
  if (x == 1) {
    background(255);
  }
  if (x == 2) {
    background(127);
  }

  //  stroke(255);
  // use the mix buffer to draw the waveforms.
  // because these are MONO files, we could have used the left or right buffers and got the same data
  if (x == 0) {
    for (int i = 0; i < kick2.bufferSize() - 1; i++)
    {
      stroke(0xffE82C2C);
      noFill();
      line(i, 540 - kick2.left.get(i)*300, i+1560, 540 - kick2.left.get(i+1)*300);
      //        rect(i, 360 - kick2.left.get(i)*300, i+1560, 360 - kick2.left.get(i+1)*300);
      //    ellipse(360 - kick2.left.get(i)*1, 360 - kick2.left.get(i)*1,360 - kick2.left.get(i)*1, 360 - kick2.left.get(i+1)*300);
      //    beginShape(TRIANGLES);
      //    vertex(i, 540 - kick2.left.get(i)*300);
      //    vertex(540 - kick2.left.get(i)*300, i);
      //    vertex(i+100, 540 - kick2.left.get(i)*300);
      //    vertex(540 - kick2.left.get(i)*300, i+100);
      //    vertex(i+300, 540 - kick2.left.get(i)*300);
      //    vertex(540 - kick2.left.get(i)*300, i+300);
      //    endShape();
      //    triangle(i, 540 - kick2.left.get(i)*300,i+780,0 - kick2.left.get(i+1)*300,i+1560, 540 - kick2.left.get(i+1)*300);
    }

    for (int i = 0; i < he.bufferSize() - 1; i++)
    {
      stroke(0xff1993DE);
      line(i, 540 - he.left.get(i)*400, i+1560, 540 - he.left.get(i+1)*400);
    }

    for (int i = 0; i < clap.bufferSize() - 1; i++)
    {
      stroke(0xff8853CE);
      line(i, 540 - clap.left.get(i)*400, i+1560, 540 - clap.left.get(i+1)*400);
    }

    for (int i = 0; i < phresh.bufferSize() - 1; i++)
    {
      stroke(0xff7EFFDE);
      line(i, 540 - phresh.left.get(i)*300, i+1560, 540 - phresh.left.get(i+1)*300);
    }

    for (int i = 0; i < airhorn.bufferSize() - 1; i++)
    {
      stroke(0xffE07810);
      line(i, 540 - airhorn.left.get(i)*300, i+1560, 540 - airhorn.left.get(i+1)*300);
    }
  }
  
///////////////////////////// 
///////////////////////////// 808's 
  if (x == 1) {
    for (int i = 0; i < bd808.bufferSize() - 1; i++)
    {
      stroke(0xffE82C2C);
      noFill();
      line(i, 540 - bd808.left.get(i)*400, i+1560, 540 - bd808.left.get(i+1)*400);
    }
    
for (int i = 0; i < cowbell808.bufferSize() - 1; i++)
    {
      stroke(0xff1993DE);
      line(i, 540 - cowbell808.left.get(i)*500, i+1560, 540 - cowbell808.left.get(i+1)*500);
    }
        for (int i = 0; i < clap808.bufferSize() - 1; i++)
    {
      stroke(0xff8853CE);
      line(i, 540 - clap808.left.get(i)*500, i+1560, 540 - clap808.left.get(i+1)*500);
    }
        for (int i = 0; i < snare808.bufferSize() - 1; i++)
    {
      stroke(0xff7EFFDE);
      line(i, 540 - snare808.left.get(i)*500, i+1560, 540 - snare808.left.get(i+1)*500);
    }
        for (int i = 0; i < hihat808.bufferSize() - 1; i++)
    {
      stroke(0xffE07810);
      line(i, 540 - hihat808.left.get(i)*500, i+1560, 540 - hihat808.left.get(i+1)*500);
    }
  }
  ///////////////////////////// 
///////////////////////////// Tones 
  if (x == 2) {
    for (int i = 0; i < kick.bufferSize() - 1; i++)
    {
      stroke(0xffE82C2C);
      noFill();
      line(i, 540 - kick.left.get(i)*400, i+1560, 540 - kick.left.get(i+1)*400);
    }
    
for (int i = 0; i < mnt4.bufferSize() - 1; i++)
    {
      stroke(0xff1993DE);
      line(i, 540 - mnt4.left.get(i)*500, i+1560, 540 - mnt4.left.get(i+1)*500);
    }
        for (int i = 0; i < mnt1.bufferSize() - 1; i++)
    {
      stroke(0xff8853CE);
      line(i, 540 - mnt1.left.get(i)*500, i+1560, 540 - mnt1.left.get(i+1)*500);
    }
        for (int i = 0; i < mnt2.bufferSize() - 1; i++)
    {
      stroke(0xff7EFFDE);
      line(i, 540 - mnt2.left.get(i)*500, i+1560, 540 - mnt2.left.get(i+1)*500);
    }
        for (int i = 0; i < mnt3.bufferSize() - 1; i++)
    {
      stroke(0xffE07810);
      line(i, 540 - mnt3.left.get(i)*500, i+1560, 540 - mnt3.left.get(i+1)*500);
    }
  }

  for (int i = 0; i < imma.bufferSize() - 1; i++)
  {
    stroke(0xffD6E817);
    line(i, 540 - imma.left.get(i)*400, i+1560, 540 - imma.left.get(i+1)*400);
  }
  //  image(movie,movie.width, movie.height);
}

public void keyPressed()
{
  if ( key == 'k' ) kick2.trigger();
  if ( key == 'c' ) clap.trigger();
  if ( key == 'f' ) phresh.trigger();

  if (x == 0) {
    if ( key == 32 ) he.trigger();
  }
  if (x == 1) {
    if ( key == 32 ) cowbell808.trigger();
  }
  if (x == 2) {
    if ( key == 32 ) mnt4.trigger();
  }



  if (key == CODED) {
    if (x == 0) {
      if (keyCode == UP) {
        kick2.trigger();
        //      movie.loop();
      }
      if (keyCode == RIGHT) {
        clap.trigger();
      }
      if (keyCode == DOWN) {
        phresh.trigger();
      }
      if (keyCode == LEFT) {
        airhorn.trigger();
      }
    }
    ///////////////////////////////
    if (x == 1) {
      if (keyCode == UP) {
        bd808.trigger();
        //      movie.loop();
      }
      if (keyCode == RIGHT) {
        clap808.trigger();
      }
      if (keyCode == DOWN) {
        snare808.trigger();
      }
      if (keyCode == LEFT) {
        hihat808.trigger();
      }
    }
    ///////////////////////////////
    if (x == 2) {
      if (keyCode == UP) {
        kick.trigger();
        //      movie.loop();
      }
      if (keyCode == RIGHT) {
        mnt1.trigger();
      }
      if (keyCode == DOWN) {
        mnt2.trigger();
      }
      if (keyCode == LEFT) {
        mnt3.trigger();
      }
    }

    //    movie.noLoop();
  }
}

public void mousePressed() {
  if (mousePressed == true) {
    imma.trigger();
    x = x+1;
    if (x > 2) {
      x = 0;
    }
  }
}

public void stop()
{
  // always close Minim audio classes when you are done with them
  kick.close();
  kick2.close();
  airhorn.close();
  phresh.close();
  clap.close();
  imma.close();
  minim.stop();

  super.stop();
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "MakeyMakeyTheTech" });
  }
}
